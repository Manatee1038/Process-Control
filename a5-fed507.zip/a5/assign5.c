#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/wait.h>

int i = 1;
int j;
char* execArgv[6];

int nextFunction(int argc, char* argv[]) {
    if (i == argc)
        return 0;
    
    j=0;
    for (i = i; i<argc; ++i) {
        if (i==argc-1) {
            execArgv[j] = argv[i];
            execArgv[j+1] = NULL;
            ++i;
            break;
        }
        else if (strcmp(argv[i], ",") == 0) {
            execArgv[j] = NULL;
            ++i;
            break;
        }
        execArgv[j] = argv[i];
        ++j;
    }

    return 1;
}

int main(int argc, char* argv[]) {
    long pid;
    long ppid;
    long forkID;
    int numFunctions = 0;

    if (i == argc)
        return 0;

    while (1) {
        if (nextFunction(argc, argv) == 1) {
            ++numFunctions;
            forkID = fork();
        }
        else
            break;

        switch(forkID) {
            case 0:
                pid = getpid();
                ppid = getppid();
                printf("PID: %ld, PPID: %ld, CMD: %s\n", pid, ppid, execArgv[0]);
                execvp(execArgv[0], execArgv);
                break;
        }
    }
    for (i = 0; i < numFunctions; ++i) {
        wait(NULL);
    }
    return 0;
}
